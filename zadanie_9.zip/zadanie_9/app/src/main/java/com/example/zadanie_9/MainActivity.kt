package com.example.zadanie_9

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import com.example.zadanie_9.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val MainBinding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        setContentView(MainBinding.root)

        with(MainBinding.root){

        }
    }

    val contentList = arrayListOf<Contact>(
        Contact("U1", "", "Text1"),
        Contact("U2", "", "Text2"),
        Contact("U3", "", "Text3"),
        Contact("U4", "", "Text4"),

    )
}